#include "physics.h"
physics::physics() {

}
void physics::computeVel(std::vector<worldObject*>& worldObjects, float dt) {
	dt *= (3600 * 24);
	for (int i = 0; i < worldObjects.size(); i++) {
		worldObjects.at(i)->acceleration = glm::vec3(0.0f, 0.0f, 0.0f);
		for (int j = 0; j < worldObjects.size(); j++) {
			if (i!=j) {
				direction = glm::normalize(worldObjects.at(j)->position - worldObjects.at(i)->position);
				distance = glm::distance(worldObjects.at(j)->position, worldObjects.at(i)->position);
				worldObjects.at(i)->acceleration += direction * (gravitationalConst * (worldObjects.at(j)->mass) / (distance*distance));
			}
		}
	}
}