#include "game.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
//mouse movement
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
//positions camera    (eye = camera pos, center = where we look at, up = camera upside)    Right hand technique
glm::vec3 eye = glm::vec3(0.0f, -2613.0f, 0.0f);
glm::vec3 center = glm::vec3(0.0f, 1.0f, 0.0f);
glm::vec3 up = glm::vec3(0.0f, 0.0f, 1.0f);

bool altPressed = 0;
bool altRelease = 0;

bool firstMouse = true;
float lastX = 400, lastY = 300;
float yaw = 90.0f;
float pitch = 0.0f;

float xoffset;
float yoffset;

//constructor & destructor
Game::Game(const unsigned int SCR_WIDTH, const unsigned int SCR_HEIGHT, const char* name)
    :scrWidth(SCR_WIDTH), scrHeight(SCR_HEIGHT)
{
    dt = 0.0f;

    //initialise window
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    //create window
    window = glfwCreateWindow(scrWidth, scrHeight, name, NULL, NULL);
    glfwMakeContextCurrent(window);

    //set callbacks
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPosCallback(window, mouse_callback);

    // glad: load all OpenGL function pointers
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
    }

    glEnable(GL_DEPTH_TEST);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);    //Show lines
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    //io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
    //io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
    //ImGui::StyleColorsClassic();

    // Setup Platform/Renderer bindings
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init((char*)glGetString(GL_NUM_SHADING_LANGUAGE_VERSIONS));
}
Game::~Game() { 
}
//Game state
void Game::init()
{
    //----------testing-----------


    //----------testing-----------
    //create shader object
    Shader shader = ResourceManager::LoadShader("shaders/shader.vert", "shaders/shader.frag", nullptr, "shader");
    //perspective projection
    glm::mat4 projection = glm::mat4(1.0f);
    projection = glm::perspective(glm::radians(45.0f), 1920.0f/ 1080.0f , 0.1f, 30000.0f);
    //glm::mat4 projection = glm::ortho(0.0f, scrWidth, scrHeight, 0.0f, -1000.0f, 1000.0f);
    ResourceManager::GetShader("shader").Use();
    glUniform1i(glGetUniformLocation(ResourceManager::GetShader("shader").ID, "image"), 0);
    glUniformMatrix4fv(glGetUniformLocation(ResourceManager::GetShader("shader").ID, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

    renderer = new SpriteRenderer(shader);
    bodyPhysics = new physics();
    //Create world objects
    worldObjects.push_back(new worldObject(glm::vec4(0.4f, 0.5f, 1.0f, 1.0f), glm::vec3(0.0f, 0.0f, 0.0f),                               glm::vec3(0.0f, -12.5f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f),  5.972f * std::pow(10, 24))  );
    worldObjects.push_back(new worldObject(glm::vec4(1.0f, 0.35f, 0.07f, 1.0f), glm::vec3(384400.0f*1000.0f, 0.0f, 0.0f),                glm::vec3(0.0f, 1024.0f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f), 7.348f * std::pow(10, 22))  );
    worldObjects.push_back(new worldObject(glm::vec4(0.5f, 0.4f, 0.4f, 1.0f), glm::vec3(0.0f, 0.0f, 384400.0f * 1000.0f),                glm::vec3(0.0f, 1024.0f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f), 7.348f * std::pow(10, 22)));
    worldObjects.push_back(new worldObject(glm::vec4(0.7f, 0.3f, 0.7f, 1.0f), glm::vec3( 40000.0f * 1000.0f, 0.0f, 70000.0f*1000),       glm::vec3(0.0f, 1024.0f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f), 7.348f * std::pow(10, 23)));
    worldObjects.push_back(new worldObject(glm::vec4(0.3f, 0.45f, 0.3f, 1.0f), glm::vec3(0.0f, 384400.0f * 1000.0f, 0.0f),               glm::vec3(0.0f, 1024.0f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f), 7.348f * std::pow(10, 22)));
    worldObjects.push_back(new worldObject(glm::vec4(0.1f, 0.8f, 0.4f, 1.0f), glm::vec3( 384400.0f * 1000.0f, 70000.0f * 1000, 0.0f),    glm::vec3(0.0f, 1024.0f, 0.0f), glm::vec3(0.0f, 0.0f, 0.0f), 7.348f * std::pow(10, 22)));
    
}
//--------imgui--------
void Game::renderImgui(float deltaTime) {

    dt = deltaTime * fastforwardScalar;
    dtMovement = deltaTime;
    timePassed += dt;
    ImGui_ImplOpenGL3_NewFrame();

    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    {
        ImGui::Begin("Executions");
        // ImGui::Text("");
        ImGui::SliderFloat("x: %.1f meters", &worldObjects.at(0)->position.x, -500000000.0f, 500000000.0f);
        ImGui::SliderFloat("y: %.1f meters", &worldObjects.at(0)->position.y, -500000000.0f, 500000000.0f);
        ImGui::SliderFloat("z: %.1f meters", &worldObjects.at(0)->position.z, -500000000.0f, 500000000.0f);
        ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
        
        ImGui::SliderFloat("Fastforward", &fastforwardScalar, -10.0f, 10.0f);

        ImGui::Text("Time passed: %.2f Days", timePassed);
        ImGui::End();
    }

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

}
//Gameloop
void Game::handleEvents() 
{
    //Input
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        eye += center * dtMovement * 3500.0f;
    }
    else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        eye -= center * dtMovement * 3500.0f;
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        eye.x -= (center.x * cos(glm::radians(-90.0f)) - center.y * sin(glm::radians(-90.0f))) * dtMovement * 3500.0f;
        eye.y -= (center.x * sin(glm::radians(-90.0f)) + center.y * cos(glm::radians(-90.0f))) * dtMovement * 3500.0f;
    }
    else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        eye.x -= (center.x * cos(glm::radians(90.0f)) - center.y * sin(glm::radians(90.0f))) * dtMovement * 3500.0f;
        eye.y -= (center.x * sin(glm::radians(90.0f)) + center.y * cos(glm::radians(90.0f))) * dtMovement * 3500.0f;
    }
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        eye.z += 3500.0f * dtMovement;
    }
    else if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) {
        eye.z -= 3500.0f * dtMovement;
    }
    if (glfwGetKey(window, GLFW_KEY_LEFT_ALT) == GLFW_PRESS) {
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        altPressed = 1;
    }
    else if(glfwGetKey(window, GLFW_KEY_LEFT_ALT) != GLFW_PRESS){
        altPressed = 0;
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    }
    if (glfwGetKey(window, GLFW_KEY_LEFT_ALT) == GLFW_RELEASE) {
        altRelease = 1;
        glfwSetCursorPos(window, lastX, lastY);
    }
}

void Game::render()
{
    //view matrix
    glm::mat4 view;
    view = glm::lookAt(eye, eye + center, up);

    glUniformMatrix4fv(glGetUniformLocation(ResourceManager::GetShader("shader").ID, "view") , 1, GL_FALSE, glm::value_ptr(view));

    //draw objectsglBindVertexArray(VAO);
    bodyPhysics->computeVel(worldObjects, dt);
    //worldObjects.at(1)->velocity += glm::normalize(worldObjects.at(0)->position - worldObjects.at(1)->position) * 1000.0f * dt;
    //worldObjects.at(0)->velocity += glm::normalize(worldObjects.at(1)->position - worldObjects.at(0)->position)*1000.0f*dt;
    for (int i = 0; i < worldObjects.size(); i++) {
        worldObjects.at(i)->drawWorldObject(*renderer, dt);
    }
    // this->renderer->DrawSprite(glm::vec4(1.0f, 0.5f, 0.0f, 1.0f), glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(1000.0f, 1000.0f, 1000.0f), glm::vec3(0.0f, 0.0f, 0.0f));
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (altPressed == 0) {
        if (firstMouse)
        {
            lastX = xpos;
            lastY = ypos;
            firstMouse = false;
        }
        xoffset = lastX - xpos;
        yoffset = lastY - ypos;
        lastX = xpos;
        lastY = ypos;

        float sensitivity = 0.05;
        xoffset *= sensitivity;
        yoffset *= sensitivity;

        yaw += xoffset;
        pitch += yoffset;

        if (pitch > 89.0f)
            pitch = 89.0f;
        if (pitch < -89.0f)
            pitch = -89.0f;

        glm::vec3 direction;
        direction.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
        direction.z = sin(glm::radians(pitch));
        direction.y = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
        center = glm::normalize(direction);
    }
}

//------CALLBACKS---------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


//---------getset---------
GLFWwindow* Game::getWindow() {
    return window;
}