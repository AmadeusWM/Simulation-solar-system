#include "worldObject.h"
worldObject::worldObject(glm::vec4 Color, glm::vec3 Pos, glm::vec3 Velocity, glm::vec3 Rotation, float Mass)
	:color(Color), position(Pos), velocity(Velocity), rotation(Rotation), mass(Mass)
{
	float xyzSize = cbrt(mass / 5510.0f);
	size = glm::vec3(xyzSize, xyzSize, xyzSize);
}
worldObject::~worldObject() {
}
void worldObject::drawWorldObject(SpriteRenderer& renderer , float dt) {
	velocity += acceleration* (dt * 3600 * 24);
	//std::cout << velocity.y << "\n";
	position += velocity * (dt * 3600 * 24);
	renderer.DrawSprite(color, position, size, rotation);
}